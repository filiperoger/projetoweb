package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Medico;
import util.DBUtil;

public class MedicoDAO {

	private Connection conn;

	public MedicoDAO() {
		conn = DBUtil.getConnection();
	}

	public void adicionar(Medico medico) {
		try {
			String query = "insert into medico (nome) values (?)";
			PreparedStatement preparedStatement = conn.prepareStatement( query );
			preparedStatement.setString( 1, medico.getNome() );
//			preparedStatement.setString( 2, usuario.getEmail() );
//			preparedStatement.setString( 3, usuario.getTelefone() );
//			preparedStatement.setString( 4, usuario.getEndereco());
//			preparedStatement.setString( 5, usuario.getLogin());
//			preparedStatement.setString( 6, usuario.getSenha());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void alterar(Medico medico) {
		try {
			String query = "update medico set nome=? where medicoId=?";
			PreparedStatement preparedStatement = conn.prepareStatement( query );
			preparedStatement.setInt(1, medico.getMedicoId());
			preparedStatement.setString( 2, medico.getNome());
//			preparedStatement.setString( 2, usuario.getEmail());
//			preparedStatement.setString( 3, usuario.getTelefone() );
//			preparedStatement.setString( 4, usuario.getEndereco() );
//			preparedStatement.setString(5, usuario.getLogin());
//			preparedStatement.setString(6, usuario.getSenha());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void excluir(int medicoId) {
		try {
			String query = "delete from medico where medicoId=?";
			PreparedStatement preparedStatement = conn.prepareStatement(query);
			preparedStatement.setInt(1, medicoId);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	public List<Medico> listarTodos() {
		List<Medico> medicos = new ArrayList<Medico>();
		try {
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery( "select * from medico" );
			while( resultSet.next() ) {
				Medico medico = new Medico();
				medico.setMedicoId (resultSet.getInt( "medicoId" ) );
				medico.setNome( resultSet.getString( "nome" ) );
//				usuario.setEmail( resultSet.getString( "email" ) );
//				usuario.setTelefone( resultSet.getString( "telefone" ) );
//				usuario.setEndereco( resultSet.getString( "endereco" ) );
//				usuario.setLogin( resultSet.getString( "login" ) );
//				usuario.setSenha( resultSet.getString( "senha" ) );
				medicos.add(medico);
			}
			resultSet.close();
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return medicos;
	}
}
