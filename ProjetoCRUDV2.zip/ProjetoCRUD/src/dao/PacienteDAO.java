package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Paciente;
import util.DBUtil;

public class PacienteDAO {

	private Connection conn;

	public PacienteDAO() {
		conn = DBUtil.getConnection();
	}

	public void adicionar(Paciente paciente) {
		try {
			String query = "insert into paciente (nome) values (?)";
			PreparedStatement preparedStatement = conn.prepareStatement( query );
			preparedStatement.setString( 1, paciente.getNome() );
//			preparedStatement.setString( 2, usuario.getEmail() );
//			preparedStatement.setString( 3, usuario.getTelefone() );
//			preparedStatement.setString( 4, usuario.getEndereco());
//			preparedStatement.setString( 5, usuario.getLogin());
//			preparedStatement.setString( 6, usuario.getSenha());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void alterar(Paciente paciente) {
		try {
			String query = "update paciente set nome=? where pacienteId=?";
			PreparedStatement preparedStatement = conn.prepareStatement( query );
			preparedStatement.setInt(1, paciente.getPacienteId());
			preparedStatement.setString( 2, paciente.getNome());
//			preparedStatement.setString( 2, usuario.getEmail());
//			preparedStatement.setString( 3, usuario.getTelefone() );
//			preparedStatement.setString( 4, usuario.getEndereco() );
//			preparedStatement.setString(5, usuario.getLogin());
//			preparedStatement.setString(6, usuario.getSenha());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void excluir(int pacienteId) {
		try {
			String query = "delete from paciente where pacienteId=?";
			PreparedStatement preparedStatement = conn.prepareStatement(query);
			preparedStatement.setInt(1, pacienteId);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	public List<Paciente> listarTodos() {
		List<Paciente> pacientes = new ArrayList<Paciente>();
		try {
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery( "select * from paciente" );
			while( resultSet.next() ) {
				Paciente paciente = new Paciente();
				paciente.setPacienteId (resultSet.getInt( "pacienteId" ) );
				paciente.setNome( resultSet.getString( "nome" ) );
//				usuario.setEmail( resultSet.getString( "email" ) );
//				usuario.setTelefone( resultSet.getString( "telefone" ) );
//				usuario.setEndereco( resultSet.getString( "endereco" ) );
//				usuario.setLogin( resultSet.getString( "login" ) );
//				usuario.setSenha( resultSet.getString( "senha" ) );
				pacientes.add(paciente);
			}
			resultSet.close();
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pacientes;
	}
}
