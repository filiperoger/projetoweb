package model;

public class Medico {
	
	private int medicoId;
	private String nome;

	public int getMedicoId() {
		return medicoId;
	}
	public void setMedicoId(int medicoId) {
		this.medicoId = medicoId;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@Override
    public String toString() {
        return "Medico [medicoId=" + medicoId + ", nome=" + nome + "]";
    } 
}
