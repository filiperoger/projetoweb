CREATE TABLE usuario (
	 usuarioId integer NOT NULL IDENTITY,
	 nome varchar(40) NULL,
	 email varchar(40) NULL,
	 login varchar(20) NULL,
	 senha varchar(20) NULL,
 PRIMARY KEY (usuarioId));
 
CREATE TABLE medico (
	medicoId integer NOT NULL IDENTITY,
	nome varchar(40) NULL,
 	PRIMARY KEY (medicoId)
 );
 
CREATE TABLE paciente (
	pacienteId integer NOT NULL IDENTITY,
	nome varchar(40) NULL,
	PRIMARY KEY (pacienteId)
);