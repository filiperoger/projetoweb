CREATE TABLE usuario (
	 usuarioId integer NOT NULL IDENTITY,
	 nome varchar(40) NULL,
	 email varchar(40) NULL,
	 telefone varchar(20) NULL,
	 endereco varchar(70) NULL,
	 login varchar(20) NULL,
	 senha varchar(20) NULL,
 PRIMARY KEY (usuarioId));

CREATE TABLE anuncio ( 
	anuncioId integer NOT NULL IDENTITY,
	titulo varchar(30) NULL,
	descricao varchar(70) NULL,
	id_usuario integer,
	PRIMARY KEY (anuncioId),
constraint fk_usuario foreign key ( id_usuario ) REFERENCES usuario ( usuarioId ));