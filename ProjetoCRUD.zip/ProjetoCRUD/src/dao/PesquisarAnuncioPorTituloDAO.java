package dao;

import java.sql.ResultSet;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import util.DBUtil;
import model.Anuncio;

public class PesquisarAnuncioPorTituloDAO {

	public static List<Anuncio> anuncioPorTitulo(String titulo) {
		ResultSet rs = null;
		InputStream inputStream = DBUtil.class.getClassLoader().getResourceAsStream("/db.properties");		

		Properties properties = new Properties();
		List<Anuncio> anuncios = new ArrayList<Anuncio>();
		try {
			
			properties.load(inputStream);
			String driver = properties.getProperty("driver");
			String url = properties.getProperty("url");
			String user = properties.getProperty("user");
			String password = properties.getProperty("password");

			// loading drivers for mysql
			Class.forName(driver);

			// creating connection with the database
			Connection con = DriverManager.getConnection(url, user, password);
			PreparedStatement ps = (PreparedStatement) con
					.prepareStatement("select * from anuncio where titulo=?");
			ps.setString(1, titulo);
			rs = ps.executeQuery();
			
			if (rs.next()) {
				Anuncio anuncio = new Anuncio();
				anuncio.setTitulo( rs.getString( "titulo") );
				anuncio.setDescricao( rs.getString( "descricao") );
				anuncios.add(anuncio);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return anuncios;
	}

}