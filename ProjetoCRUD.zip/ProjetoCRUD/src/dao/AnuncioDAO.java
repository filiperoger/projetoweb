package dao;

import java.util.List;

import model.Anuncio;

public interface AnuncioDAO {
	public void adicionarAnuncio(Anuncio anuncio);
	public void excluirAnuncio(int  anuncioId);
	public void alterarAnuncio(Anuncio anuncio);
	public List<Anuncio> listarTodosAnuncios();
	public Anuncio buscarAnuncioPorId(int anuncioId);
	public List<Anuncio> listarAnuncioPorUsuario (int usuarioId);
	public List<Anuncio> listarAnuncioPorTitulo (String titulo);
}
